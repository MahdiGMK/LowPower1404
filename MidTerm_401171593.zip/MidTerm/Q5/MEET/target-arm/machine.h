#define MD_CLOCK_CYCLES_PER_MICROSECOND     25 /* i.e. 25MHz processor */
#define MD_CLOCK_CYCLES_PER_MICROSECOND     25 /* i.e. 25MHz processor */
#define MD_CLOCK_CYCLES_PER_MICROSECOND     25 /* i.e. 25MHz processor */
