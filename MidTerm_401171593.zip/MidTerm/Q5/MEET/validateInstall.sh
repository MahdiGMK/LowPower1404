#!/bin/bash
./run.sh tests/quicksort main
